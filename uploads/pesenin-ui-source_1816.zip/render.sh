#!/bin/bash
cd /workspace/pesenin-ui
mkdir -p screens
for f in src/*.html; do n=$(basename $f .html)
google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --force-device-scale-factor=2 --window-size=390,844 --virtual-time-budget=1500 --screenshot=screens/$n.png file://$PWD/$f 2>/dev/null &
done; wait
