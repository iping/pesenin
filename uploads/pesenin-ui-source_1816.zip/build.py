# Generates Pesenin UI mockup HTML files (390x844 PWA viewport)
import os
D=os.path.dirname(os.path.abspath(__file__))
P={'home':'<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
'list':'<rect x="5" y="3" width="14" height="18" rx="3"/><path d="M9 8h6M9 12h6M9 16h3"/>',
'box':'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
'coin':'<circle cx="12" cy="12" r="9"/><path d="M12 6.5v11M15 9h-4a1.75 1.75 0 0 0 0 3.5h2a1.75 1.75 0 0 1 0 3.5H9"/>',
'user':'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
'copy':'<rect x="9" y="9" width="12" height="12" rx="3"/><path d="M5 15V6a3 3 0 0 1 3-3h7"/>',
'back':'<path d="M15 18l-6-6 6-6"/>','chev':'<path d="M9 6l6 6-6 6"/>',
'share':'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',
'clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
'upload':'<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>','check':'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
'pin':'<path d="M12 21s-7-6.5-7-12a7 7 0 0 1 14 0c0 5.5-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/>',
'bag':'<path d="M5 8h14l-1.2 12.2a1 1 0 0 1-1 .8H7.2a1 1 0 0 1-1-.8z"/><path d="M9 8a3 3 0 0 1 6 0"/>',
'bell':'<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
'cam':'<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
'edit':'<path d="M4 20h4L19 9l-4-4L4 16z"/>','cal':'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
'search':'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>','plus':'<path d="M12 5v14M5 12h14"/>',
'dl':'<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>','truck':'<path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
'shield':'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
'lock':'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
'info':'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>','x':'<path d="M6 6l12 12M18 6 6 18"/>',
'wa':'<path d="M4 20l1.3-4A8 8 0 1 1 8 19z"/><path d="M9 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 .8c-1-.5-1.8-1.3-2.3-2.3l.8-1-1-2z"/>',
'qr':'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M21 14v7h-4M14 21v-3"/>',
'more':'<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
'spark':'<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/>',
}
def I(n,s=20,c=None,w=None):
    st=f'width:{s}px;height:{s}px;'+(f'color:{c};' if c else '')+(f'stroke-width:{w};' if w else '')
    return f'<svg class="i" viewBox="0 0 24 24" style="{st}">{P[n]}</svg>'
GOOGLE='<svg viewBox="0 0 48 48" width="20" height="20"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.6-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.5z"/></svg>'
def BOWL(on=True,s=18):
    f='#F7861E' if on else '#E3D8CE'; st='#4A2A1A' if on else '#CDBFB3'
    steam=f'<path d="M9 2.5c-1 1.2 1 2 0 3.3M13 2.5c-1 1.2 1 2 0 3.3" stroke="{st}" stroke-width="1.6" fill="none" stroke-linecap="round"/>' if on else ''
    return f'<svg viewBox="0 0 24 24" width="{s}" height="{s}" style="flex:none">{steam}<path d="M2.5 10h19a9.5 9 0 0 1-19 0z" fill="{f}" stroke="{st}" stroke-width="1.6" stroke-linejoin="round"/><path d="M6 13.5h12" stroke="#fff" stroke-width="1.4" opacity=".6" stroke-linecap="round"/><rect x="8" y="19" width="8" height="2.5" rx="1.2" fill="{st}"/></svg>'
SB='''<div class="sb"><span class="fd">18.21</span><span class="r">
<svg width="18" height="12" viewBox="0 0 18 12"><rect x="0" y="8" width="3" height="4" rx="1" fill="#4A2A1A"/><rect x="5" y="5.5" width="3" height="6.5" rx="1" fill="#4A2A1A"/><rect x="10" y="3" width="3" height="9" rx="1" fill="#4A2A1A"/><rect x="15" y="0" width="3" height="12" rx="1" fill="#4A2A1A"/></svg>
<svg width="16" height="12" viewBox="0 0 16 12"><path d="M8 11.5 5.6 9a3.4 3.4 0 0 1 4.8 0zM3.5 7a6.4 6.4 0 0 1 9 0l-1.4 1.4a4.4 4.4 0 0 0-6.2 0zM1 4.5a10 10 0 0 1 14 0l-1.4 1.4a8 8 0 0 0-11.2 0z" fill="#4A2A1A"/></svg>
<svg width="27" height="13" viewBox="0 0 27 13"><rect x=".5" y=".5" width="23" height="12" rx="3.5" stroke="#4A2A1A" opacity=".5" fill="none"/><rect x="2" y="2" width="17" height="9" rx="2" fill="#4A2A1A"/><rect x="24.5" y="4.5" width="2" height="4" rx="1" fill="#4A2A1A" opacity=".5"/></svg></span></div>'''
def URL(path):
    return f'<div class="url"><div class="pill">{I("lock",13)}<span><b>pesenin.product.biz.id</b>/{path}</span></div><div style="width:34px;height:34px;border-radius:12px;background:#fff;display:flex;align-items:center;justify-content:center;color:var(--b2)">{I("share",17)}</div></div>'
def page(name,body,cust=True,bg='var(--c)',path='dapur-senja',top=''):
    head=SB+(URL(path) if cust else '')
    html=f'''<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=390,initial-scale=1">
<title>Pesenin · {name}</title><link rel="stylesheet" href="style.css"></head>
<body style="background:{bg}">{top}{head}<div class="screen {'c-scr' if cust else 's-scr'}">{body}</div><div class="home-ind"></div></body></html>'''
    open(os.path.join(D,name+'.html'),'w').write(html)
def NAV(on):
    items=[('home','Beranda',''),('list','Pesanan','5'),('box','PO',''),('coin','Koin',''),('user','Akun','')]
    s='<div class="nav">'
    for i,(ic,l,n) in enumerate(items):
        s+=f'<a class="{"on" if l==on else ""}"><span class="ic">{I(ic,22)}</span>{l}'+(f'<span class="n">{n}</span>' if n else '')+'</a>'
    return s+'</div>'
def food(e,bg,s=64,fs=34,r=16):
    return f'<div class="thumb" style="width:{s}px;height:{s}px;background:{bg};border-radius:{r}px"><span class="food" style="font-size:{fs}px">{e}</span></div>'
def ph(s=64,r=16,kind='1x1'):
    return f'<div class="thumb" style="width:{s}px;height:{s}px;border-radius:{r}px"><img src="assets/placeholder-{kind}.png"></div>'
def HDR(t,sub='',right=''):
    return f'<div class="hdr"><div class="bk">{I("back",20)}</div><div class="col sp"><h1>{t}</h1>'+(f'<span class="xs muted bold">{sub}</span>' if sub else '')+f'</div>{right}</div>'
BREAD='linear-gradient(135deg,#FFE7C2,#FFD39A)'; CHEESE='linear-gradient(135deg,#FFF3B8,#FFE07A)'; COF='linear-gradient(135deg,#EBD7C4,#D8B795)'; CHOC='linear-gradient(135deg,#E9D3C3,#CDA98F)'

# ================= CUSTOMER 1: STORE PAGE =================
def prod(img,name,desc,price,qty,extra=''):
    ctl=(f'<div class="stepper"><span>−</span><b>{qty}</b><span>+</span></div>' if qty else '<div class="addbtn">+</div>')
    return f'''<div class="row g12" style="padding:10px 0;border-bottom:1px dashed var(--line)">{img}
<div class="col sp" style="min-width:0;gap:2px"><div class="h" style="font-size:15px">{name}</div><div class="xs muted" style="line-height:1.3">{desc}</div>
<div class="row" style="margin-top:4px;gap:8px"><b class="fd" style="font-size:15px">{price}</b>{extra}</div></div>{ctl}</div>'''
c1=f'''
<div style="height:118px;margin:0 12px;border-radius:22px;position:relative;overflow:hidden;background:linear-gradient(120deg,#FFB35C,#F7861E 60%,#F26D0F)">
 <div style="position:absolute;inset:0;opacity:.22;background-image:radial-gradient(#fff 2px,transparent 2.5px);background-size:18px 18px"></div>
 <span class="food" style="position:absolute;right:18px;top:14px;font-size:54px;transform:rotate(-12deg)">🥐</span>
 <span class="food" style="position:absolute;right:92px;top:46px;font-size:40px;transform:rotate(10deg)">☕</span>
 <span class="food" style="position:absolute;right:150px;top:8px;font-size:30px;transform:rotate(-6deg)">🍞</span>
 <div style="position:absolute;left:14px;top:14px;color:#fff" class="col"><span class="h" style="font-size:13px;opacity:.9">PO minggu ini</span><span class="h" style="font-size:20px;line-height:1.1">Salt bread<br>fresh Sabtu pagi!</span></div>
</div>
<div class="pad" style="margin-top:-24px;position:relative">
 <div class="card" style="padding:12px 14px">
  <div class="row g12"><img src="assets/icon.png" style="width:58px;height:56px;margin-top:-4px;filter:drop-shadow(0 3px 0 #E06F0A44)">
   <div class="col sp g4"><h2 style="font-size:19px;line-height:1.1">Dapur Senja</h2>
    <div class="row g6"><span class="badge b-open"><span class="dot"></span>Buka</span><span class="xs muted bold">Tutup jam 21.00</span></div></div>
   <div class="col" style="align-items:center;gap:2px"><div class="row" style="gap:1px">{BOWL()}{BOWL()}{BOWL(False)}</div><span class="xs bold">Enak · 2,6</span><span class="muted" style="font-size:10px">128 ulasan</span></div>
  </div>
 </div>
 <div class="card" style="margin-top:10px;padding:12px 14px;border:2px solid var(--o2)">
  <div class="row"><div class="col sp"><span class="h" style="font-size:16px">PO Batch #12</span><span class="xs muted bold">Ambil Sab, 15 Nov · tutup dalam</span></div>
   <div class="row g4 fd" style="font-weight:600">{''.join(f'<span style="background:var(--b);color:#fff;border-radius:8px;padding:3px 6px;font-size:14px">{t}</span>'+('<b style="color:var(--b)">:</b>' if k<2 else '') for k,t in enumerate(['08','42','15']))}</div></div>
  <div class="row g8" style="margin-top:8px"><div class="bar sp"><i style="width:64%"></i></div><span class="xs bold" style="color:var(--o-d)">32/50 pcs</span></div>
  <div class="row g6" style="margin-top:9px"><span class="chip on">🎉 Min. 3 pcs, diskon 10%</span><span class="chip">{I("pin",13)} Pickup / Antar</span></div>
 </div>
 <div class="row g8" style="margin-top:12px"><span class="chip on" style="background:var(--o);color:#fff;border-color:var(--o)">Semua</span><span class="chip">🥐 Salt bread</span><span class="chip">☕ Minuman</span></div>
 <div style="margin-top:2px">
 {prod(food('🥐',BREAD),'Salt Bread Original','Butter Prancis, garam laut, renyah di luar','Rp 15.000',2)}
 {prod(food('🧀',CHEESE),'Salt Bread Keju','Isi keju cheddar leleh','Rp 17.500',2,'<span class="trust t-vip" style="font-size:10px">Terlaris</span>')}
 {prod(food('☕',COF),'Kopi Susu Gula Aren','Botol 250 ml, gula aren asli','Rp 15.000',1)}
 {prod(ph(),'Salt Bread Cokelat','Dark chocolate 54%','Rp 18.000',0,'<span class="xs bold" style="color:var(--red)">Sisa 4</span>')}
 </div>
</div>
<div style="position:absolute;left:12px;right:12px;bottom:24px;height:62px;border-radius:20px;background:var(--b);display:flex;align-items:center;padding:0 8px 0 14px;gap:10px;box-shadow:0 10px 24px rgba(74,42,26,.35)">
 <div style="position:relative;color:#fff">{I("bag",26)}<span style="position:absolute;top:-6px;right:-8px;background:var(--o);color:#fff;font-size:11px;font-weight:900;border-radius:99px;padding:0 5px;border:2px solid var(--b)">5</span></div>
 <div class="col sp" style="color:#fff;margin-left:4px"><b class="fd" style="font-size:17px">Rp 80.000</b><span class="xs" style="color:var(--m);font-weight:800">✓ Diskon 10% kepake!</span></div>
 <div class="btn sm" style="height:44px;border-radius:14px">Lihat keranjang</div>
</div>'''
page('c1-store',c1)

# ================= CUSTOMER 2: CHECKOUT =================
def li(img,n,q,p):
    return f'<div class="row g10" style="padding:5px 0">{img}<div class="col sp"><b style="font-size:14px">{n}</b><span class="xs muted bold">{q}</span></div><b class="fd">{p}</b></div>'
def ln(a,b,st=''):
    return f'<div class="row" style="padding:3px 0;{st}"><span class="sp muted bold small">{a}</span><span class="bold small">{b}</span></div>'
c2=f'''{HDR('Keranjang','Dapur Senja · PO Batch #12')}
<div class="pad col g10">
 <div class="card" style="padding:6px 14px">
  {li(food('🥐',BREAD,36,20,11),'Salt Bread Original','2 × Rp 15.000','Rp 30.000')}
  {li(food('🧀',CHEESE,36,20,11),'Salt Bread Keju','2 × Rp 17.500','Rp 35.000')}
  {li(food('☕',COF,36,20,11),'Kopi Susu Gula Aren','1 × Rp 15.000','Rp 15.000')}
 </div>
 <div class="card" style="padding:12px 14px">
  <div class="sec" style="margin-bottom:8px">Cara terima</div>
  <div class="row g8">
   <div class="sp" style="border:2px solid var(--o);background:var(--o3);border-radius:14px;padding:8px 10px"><div class="row g6" style="color:var(--o-d)">{I("bag",18)}<b class="fd">Ambil sendiri</b></div><span class="xs muted bold">Gratis ongkir</span></div>
   <div class="sp" style="border:1.5px solid var(--line);border-radius:14px;padding:8px 10px"><div class="row g6">{I("truck",18)}<b class="fd">Diantar</b></div><span class="xs muted bold">+ Rp 10.000</span></div>
  </div>
  <div class="row g8" style="margin-top:8px;background:var(--m2);border-radius:12px;padding:8px 10px">{I("pin",18,'var(--m-d)')}<div class="col"><b class="small">Pos Satpam Cluster Melati</b><span class="xs muted bold">Sab, 15 Nov · 09.00–12.00</span></div></div>
 </div>
 <div class="card" style="padding:12px 14px">
  <div class="row"><div class="sec sp" style="margin:0">Data pemesan</div><span class="xs muted bold">Tanpa daftar juga bisa</span></div>
  <div class="row g8" style="margin-top:8px"><div class="inp sp">{I("user",16,'var(--b3)')}<span>Nadia Putri</span></div><div class="inp sp">{I("wa",16,'#25D366')}<span>0812 3456 7890</span></div></div>
  <div class="row g8" style="margin-top:8px;height:40px;border-radius:12px;border:1.5px solid var(--line);justify-content:center;font-weight:800;font-size:13px">{GOOGLE}Masuk dengan Google <span class="muted" style="font-weight:700">(opsional)</span></div>
 </div>
 <div class="card" style="padding:10px 14px">
  {ln('Subtotal (5 item)','Rp 80.000')}
  {ln('🎉 Diskon kampanye 10%','− Rp 8.000','color:var(--m-d)').replace('class="bold small"','class="bold small" style="color:var(--m-d)"')}
  {ln('Biaya packing','Rp 3.000')}
  {ln('Ongkir (ambil sendiri)','Rp 0')}
 </div>
</div>
<div style="position:absolute;left:0;right:0;bottom:0;background:#fff;border-radius:22px 22px 0 0;padding:12px 16px 26px;box-shadow:0 -6px 20px rgba(74,42,26,.08)" class="row g12">
 <div class="col sp"><span class="xs muted bold">Total bayar</span><b class="fd" style="font-size:22px;line-height:1.1">Rp 75.000</b><span class="muted" style="font-size:10px;font-weight:800">+ kode unik 3 digit saat bayar</span></div>
 <div class="btn" style="width:180px">Pesan sekarang {I("chev",18)}</div>
</div>'''
page('c2-checkout',c2,path='dapur-senja/keranjang')

# ================= CUSTOMER 3: PAYMENT =================
c3=f'''{HDR('Pembayaran','Pesanan #PSN-1207')}
<div class="pad col g10">
 <div class="row g10" style="background:var(--b);color:#fff;border-radius:18px;padding:10px 14px">{I("clock",22,'#FFB04D')}<div class="col sp"><span class="xs bold" style="opacity:.8">Batas: Jum, 13 Nov · 20.21</span><b class="fd" style="font-size:15px">Sisa waktu</b></div>
  <div class="row g4 fd" style="font-weight:600">{''.join(f'<span style="background:#fff;color:var(--b);border-radius:8px;padding:3px 7px;font-size:16px">{t}</span>'+('<b>:</b>' if k<2 else '') for k,t in enumerate(['01','59','12']))}</div></div>
 <div class="card" style="padding:16px;text-align:center;border:2px solid var(--o2)">
  <span class="small muted bold">Transfer tepat sejumlah</span>
  <div class="row" style="justify-content:center;gap:10px;margin:4px 0 2px"><b class="fd" style="font-size:36px;letter-spacing:.5px">Rp 75.<span style="color:var(--o);text-decoration:underline;text-decoration-thickness:3px;text-underline-offset:5px">137</span></b>
  <span style="width:38px;height:38px;border-radius:12px;background:var(--o3);color:var(--o-d);display:flex;align-items:center;justify-content:center">{I("copy",19)}</span></div>
  <div class="row g6" style="justify-content:center;font-size:12px;font-weight:700;color:var(--b2)">Pesanan Rp 75.000 <span>+</span> <span class="code" style="font-weight:900">kode unik 137</span></div>
  <div class="row g8" style="margin-top:12px;background:var(--o3);border-radius:14px;padding:10px 12px;text-align:left;align-items:flex-start"><img src="assets/icon.png" style="width:34px;height:33px"><span class="xs bold" style="line-height:1.4">3 angka terakhir (<b style="color:var(--o-d)">137</b>) itu kode unik pesananmu. Transfer pas sampai digit terakhir ya, biar penjual langsung tahu ini kamu!</span></div>
 </div>
 <div class="card" style="padding:12px 14px">
  <div class="row g10"><div style="width:52px;height:34px;border-radius:9px;background:#0060AF;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900;font-style:italic;font-size:15px;letter-spacing:.5px">BCA</div>
   <div class="col sp"><span class="xs muted bold">Bank BCA · a.n. Rini Lestari</span><b class="fd" style="font-size:19px;letter-spacing:1px">5230 8812 34</b></div>
   <div class="btn sm ghost" style="height:34px;font-size:13px;padding:0 10px;color:var(--o-d)">{I("copy",15)}Salin</div></div>
 </div>
 <div style="border:2px dashed var(--o);border-radius:20px;background:#fff;padding:14px;display:flex;align-items:center;gap:12px">
  <div style="width:52px;height:52px;border-radius:16px;background:var(--o3);color:var(--o);display:flex;align-items:center;justify-content:center">{I("cam",26)}</div>
  <div class="col sp"><b class="fd" style="font-size:15px">Upload bukti transfer</b><span class="xs muted bold">Screenshot m-banking / foto struk ATM · JPG, PNG</span></div>
 </div>
 <div class="row" style="justify-content:space-between;padding:0 6px">{''.join(f'<div class="col" style="align-items:center;gap:4px;width:96px"><span style="width:28px;height:28px;border-radius:50%;background:{bg};color:{fg};display:flex;align-items:center;justify-content:center;font-family:Fredoka;font-weight:600">{n}</span><span class="xs bold" style="text-align:center;line-height:1.2">{t}</span></div>' for n,t,bg,fg in [('1','Transfer pas<br>Rp 75.137','var(--o)','#fff'),('2','Upload<br>bukti','var(--o2)','var(--o-d)'),('3','Penjual cek<br>& konfirmasi','var(--o2)','var(--o-d)')])}</div>
 <div class="row g6 xs muted bold" style="justify-content:center">{I("shield",15,'var(--m-d)')}Uangmu langsung ke rekening penjual, tanpa perantara</div>
</div>
<div style="position:absolute;left:16px;right:16px;bottom:30px" class="col g10">
 <div class="btn">{I("upload",19)}Kirim bukti transfer</div>
 <div class="row g6 small bold" style="justify-content:center;color:var(--m-d)">{I("wa",16)}Ada kendala? Chat penjual</div>
</div>'''
page('c3-payment',c3,path='o/PSN-1207')

# ================= CUSTOMER 4: STATUS =================
def step(t,s,state,last=False):
    col={'done':'var(--m)','now':'var(--o)','todo':'#E6DCD2'}[state]
    dot=(f'<span style="width:26px;height:26px;border-radius:50%;background:{col};color:#fff;display:flex;align-items:center;justify-content:center">{I("check",15,None,3)}</span>' if state=='done' else
         f'<span style="width:26px;height:26px;border-radius:50%;background:#fff;border:3px solid var(--o);display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 5px var(--o2)"><i style="width:10px;height:10px;border-radius:50%;background:var(--o)"></i></span>' if state=='now' else
         f'<span style="width:26px;height:26px;border-radius:50%;background:#fff;border:3px solid #E6DCD2"></span>')
    line='' if last else f'<span style="position:absolute;left:12px;top:28px;bottom:-4px;width:3px;border-radius:3px;background:{"var(--m)" if state=="done" else "#EFE6DD"}"></span>'
    tc='var(--b)' if state!='todo' else 'var(--b3)'
    return f'<div class="row g12" style="position:relative;align-items:flex-start;padding-bottom:{0 if last else 11}px">{line}{dot}<div class="col" style="padding-top:2px"><b class="fd" style="font-size:15px;color:{tc}">{t}</b><span class="xs bold" style="color:{"var(--o-d)" if state=="now" else "var(--b2)"}">{s}</span></div></div>'
conf=''.join(f'<i style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;background:{c};border-radius:2px;transform:rotate({r}deg)"></i>' for x,y,w,h,c,r in [(14,12,8,4,'#F7861E',30),(40,52,6,6,'#6CC69A',0),(120,8,8,4,'#F5B700',-20),(300,14,8,4,'#6CC69A',40),(330,58,6,6,'#F7861E',0),(250,6,8,4,'#F5B700',60),(22,90,8,4,'#2F8BE6',-30),(345,100,8,4,'#2F8BE6',15),(90,98,5,5,'#F5B700',0)])
c4=f'''{HDR('Status pesanan','#PSN-1207 · Dapur Senja')}
<div class="pad col g10">
 <div class="card" style="padding:14px;position:relative;overflow:hidden;background:linear-gradient(180deg,#FFF1E2,#fff)">{conf}
  <div class="row g12" style="position:relative"><img src="assets/icon.png" style="width:78px;height:76px;transform:rotate(-6deg);filter:drop-shadow(0 4px 0 #E06F0A33)">
  <div class="col sp"><h2 style="font-size:20px;line-height:1.15">Yay, pembayaran diterima! 🎉</h2><span class="small muted bold" style="margin-top:3px">Pingping lagi bantu Dapur Senja siapin pesananmu.</span></div></div>
 </div>
 <div class="card" style="padding:14px 16px">
  {step('Dipesan','Jum, 13 Nov · 18.20','done')}
  {step('Bukti dikirim','Jum, 13 Nov · 18.31','done')}
  {step('Dibayar','Dicek penjual · 18.45','done')}
  {step('Diproses','Dipanggang Sabtu pagi, wangi! 🥐','now')}
  {step('Siap diambil','Sab, 15 Nov · 09.00–12.00 · Pos Satpam Cluster Melati','todo',True)}
 </div>
 <div class="btn wa">{I("wa",20)}Chat penjual via WhatsApp</div>
 <div class="card" style="padding:12px 14px;border:2px solid var(--m2)">
  <div class="row g10"><span style="width:40px;height:40px;border-radius:14px;background:var(--m2);color:var(--m-d);display:flex;align-items:center;justify-content:center">{I("shield",22)}</span>
   <div class="col sp"><span class="xs muted bold">Status kamu di mata penjual</span><div class="row g6"><b class="fd" style="font-size:16px">Terpercaya</b><span class="trust t-ok">✓ 4 pesanan beres</span></div></div></div>
  <div class="row g8" style="margin-top:9px"><div class="bar m sp"><i style="width:40%"></i></div><span class="xs bold muted">4/10 ke ⭐ Langganan Setia</span></div>
  <div class="xs bold" style="margin-top:8px;line-height:1.45;color:var(--b2)">💡 Tips: bayar sebelum batas waktu & ambil tepat jadwal. Langganan Setia bisa dapat prioritas kuota PO!</div>
 </div>
 <div class="row g10" style="border:2px dashed var(--o2);border-radius:18px;padding:10px 12px"><span class="food" style="font-size:24px">🤝</span><div class="col sp"><b class="fd" style="font-size:14px">Ajak tetangga ikut PO</b><span class="xs muted bold">Kuota tinggal 18 pcs, ambil bareng!</span></div><div class="btn sm ghost" style="height:34px;font-size:13px;padding:0 10px;color:var(--o-d)">{I("share",14)}Bagikan</div></div>
</div>'''
page('c4-status',c4,path='o/PSN-1207')

# ================= CUSTOMER 5: REVIEW =================
def bowlopt(n,label,sel=False):
    bs=''.join(BOWL(True,22) for _ in range(n))
    st='border:2.5px solid var(--o);background:var(--o3);box-shadow:0 4px 0 var(--o2)' if sel else 'border:2px solid var(--line);background:#fff'
    return f'<div class="col sp" style="align-items:center;gap:6px;border-radius:18px;padding:12px 4px;{st};position:relative">'+(f'<span style="position:absolute;top:-9px;right:-6px;width:22px;height:22px;border-radius:50%;background:var(--o);color:#fff;display:flex;align-items:center;justify-content:center;border:2px solid #fff">{I("check",12,None,3.5)}</span>' if sel else '')+f'<div class="row" style="gap:1px;height:24px">{bs}</div><b class="fd" style="font-size:15px;color:{"var(--o-d)" if sel else "var(--b)"}">{label}</b><span class="muted" style="font-size:10px;font-weight:800">{n} Mangkok</span></div>'
tags=[('Rotinya lembut',1),('Packing rapi',1),('Tepat waktu',0),('Kopinya mantap',1),('Porsi pas',0),('Penjual ramah',0)]
c5=f'''{HDR('Kasih ulasan','#PSN-1207 · selesai Sab, 15 Nov')}
<div class="pad col g12">
 <div class="row g10 card" style="padding:10px 12px"><img src="assets/icon.png" style="width:40px;height:39px"><div class="col sp"><b class="fd" style="font-size:15px">Dapur Senja</b><span class="xs muted bold">2 Ori · 2 Keju · 1 Kopi Susu Aren</span></div>
  <span class="trust t-ok" style="padding:4px 8px">{I("shield",13)}Terverifikasi</span></div>
 <div><h2 style="font-size:20px">Gimana rasanya? 😋</h2><span class="small muted bold">Pilih Mangkok buat Dapur Senja</span></div>
 <div class="row g8" style="margin-top:4px">{bowlopt(1,'Oke')}{bowlopt(2,'Enak')}{bowlopt(3,'Wajib coba',True)}</div>
 <div><div class="sec">Yang paling berkesan</div><div class="row" style="flex-wrap:wrap;gap:7px">{''.join(f'<span class="chip {"on" if o else ""}">{"✓ " if o else ""}{t}</span>' for t,o in tags)}</div></div>
 <div style="background:#fff;border:1.5px solid var(--line);border-radius:16px;padding:10px 12px;height:76px;font-size:14px;line-height:1.4">Salt bread kejunya juara, masih anget pas diambil. Kopinya pas manisnya 👍<span style="display:inline-block;width:2px;height:16px;background:var(--o);vertical-align:-3px;margin-left:1px"></span></div>
 <div class="row g10">{food('🥐','linear-gradient(135deg,#FFE7C2,#F9C784)',64,34,14)}
  <div class="col" style="width:64px;height:64px;border-radius:14px;border:2px dashed var(--b3);align-items:center;justify-content:center;color:var(--b2);gap:2px">{I("cam",20)}<span class="xs bold">Foto</span></div>
  <span class="xs muted bold sp" style="line-height:1.4">Foto opsional, maks. 3. Foto asli bikin ulasanmu makin dipercaya.</span></div>
</div>
<div style="position:absolute;left:16px;right:16px;bottom:30px" class="col g10">
 <div class="row g6 xs bold" style="justify-content:center;color:var(--m-d)">{I("shield",15)}Hanya pembeli terverifikasi yang bisa kasih Mangkok</div>
 <div class="btn">Kirim ulasan</div>
</div>'''
page('c5-review',c5,path='o/PSN-1207/ulasan')

# ================= SELLER 1: DASHBOARD =================
def stat(v,l,c='var(--b)',bg='#fff',ic=''):
    return f'<div class="card col sp" style="padding:10px 10px;gap:2px;background:{bg}"><span class="xs muted bold">{l}</span><b class="fd" style="font-size:20px;color:{c};line-height:1.15">{v}</b>{ic}</div>'
s1=f'''<div class="pad col g10" style="padding-top:6px">
 <div class="row g10"><img src="assets/icon.png" style="width:44px;height:43px"><div class="col sp"><span class="small muted bold">Sore, Bu Rini 👋</span><h1 style="font-size:20px">Dapur Senja</h1></div>
  <span style="position:relative;width:42px;height:42px;border-radius:14px;background:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 0 var(--line)">{I("bell",21)}<i style="position:absolute;top:9px;right:10px;width:9px;height:9px;border-radius:50%;background:var(--red);border:2px solid #fff"></i></span></div>
 <div class="card row g12" style="padding:10px 14px"><div style="position:relative"><img src="assets/icon.png" style="width:44px;height:43px"><i style="position:absolute;right:-3px;top:-3px;width:14px;height:14px;border-radius:50%;background:#2EAD5B;border:3px solid #fff"></i></div>
  <div class="col sp"><div class="row g6"><b class="fd" style="font-size:16px">Toko lagi</b><span class="badge b-open"><span class="dot"></span>Buka</span></div><span class="xs muted bold">Otomatis tutup jam 21.00 · Ubah jadwal</span></div><div class="toggle on"></div></div>
 <div style="border-radius:22px;padding:14px 16px;color:#fff;background:linear-gradient(125deg,#FFA445,#F7861E 55%,#EA6A0C);position:relative;overflow:hidden;box-shadow:0 5px 0 var(--o-d)">
  <div style="position:absolute;right:-20px;top:-26px;width:120px;height:120px;border-radius:50%;background:rgba(255,255,255,.12)"></div>
  <div class="row"><div class="col sp"><span class="small bold" style="opacity:.9">Saldo Koin</span><div class="row g8" style="margin-top:2px"><span class="koin" style="width:28px;height:28px;font-size:14px">★</span><b class="fd" style="font-size:30px;line-height:1">12.450</b></div>
  <span class="xs bold" style="opacity:.92;margin-top:5px">≈ 124 pesanan lagi · Rp 100/pesanan</span></div>
  <div class="btn sm" style="background:#fff;color:var(--o-d);box-shadow:0 3px 0 #F3C79B;position:relative">{I("plus",16,None,3)}Top up</div></div>
 </div>
 <div style="margin-top:4px"><div class="row" style="margin-bottom:8px"><span class="sec sp" style="margin:0">Hari ini</span><span class="xs muted bold">Jum, 13 Nov</span></div>
 <div class="row g8">{stat('18','Pesanan')}{stat('5','Perlu cek','var(--o-d)','#FFF8F0')}{stat('1,24 jt','Omzet','var(--m-d)')}</div></div>
 <div class="card" style="padding:12px 14px"><div class="row g8"><span style="width:34px;height:34px;border-radius:11px;background:var(--o3);color:var(--o);display:flex;align-items:center;justify-content:center">{I("box",19)}</span><div class="col sp"><b class="fd" style="font-size:15px">PO Batch #12</b><span class="xs muted bold">Tutup dalam 08:42:15 · ambil Sab, 15 Nov</span></div>{I("chev",18,'var(--b3)')}</div>
  <div class="row g8" style="margin-top:9px"><div class="bar sp"><i style="width:64%"></i></div><span class="xs bold" style="color:var(--o-d)">32/50 pcs</span></div></div>
 <div class="card row g12" style="padding:12px 14px;background:linear-gradient(120deg,#FFF8E1,#fff)">
  <div style="width:46px;height:46px;border-radius:16px;background:linear-gradient(135deg,#FFD35A,#F5B700);display:flex;align-items:center;justify-content:center;box-shadow:0 3px 0 #D99A00"><span class="food" style="font-size:24px">🔥</span></div>
  <div class="col sp"><b class="fd" style="font-size:15px">7 hari beruntun jualan!</b><span class="xs muted bold">Lv. 4 Toko Kampung · 680/1.000 XP</span><div class="bar" style="height:7px;margin-top:5px"><i style="width:68%;background:linear-gradient(90deg,#F5B700,#FFD35A)"></i></div></div>
  <div class="col" style="align-items:center"><span class="food" style="font-size:24px">🏅</span><span style="font-size:9px;font-weight:900;color:#A86A00">Raja Salt<br>Bread</span></div></div>
 <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">{''.join(f'<div class="col" style="align-items:center;gap:5px"><span style="width:52px;height:52px;border-radius:18px;background:#fff;display:flex;align-items:center;justify-content:center;color:{c};box-shadow:0 3px 0 var(--line)">{I(ic,24)}</span><span class="xs bold">{t}</span></div>' for ic,t,c in [('plus','Buat PO','var(--o)'),('share','Bagikan link','var(--m-d)'),('qr','QR toko','var(--b)'),('list','Rekap','var(--blue)')])}</div>
</div>{NAV('Beranda')}'''
page('s1-dashboard',s1,cust=False)

# ================= SELLER 2: ORDERS =================
def receipt(amt):
    return f'''<div style="width:54px;height:70px;border-radius:10px;background:#F4F6FA;border:1.5px solid #E2E6EE;flex:none;padding:6px 5px;display:flex;flex-direction:column;gap:3px;position:relative;overflow:hidden">
<div style="height:6px;width:24px;background:#0060AF;border-radius:2px"></div><div style="font-size:6px;font-weight:900;color:#2EAD5B">Berhasil ✓</div>
<div style="font-size:7px;font-weight:900;color:#333">{amt}</div><div style="height:3px;background:#DDE2EA;border-radius:2px"></div><div style="height:3px;width:70%;background:#DDE2EA;border-radius:2px"></div><div style="height:3px;width:85%;background:#DDE2EA;border-radius:2px"></div>
<span style="position:absolute;right:3px;bottom:3px;width:16px;height:16px;border-radius:6px;background:rgba(74,42,26,.7);color:#fff;display:flex;align-items:center;justify-content:center">{I("search",10,None,3)}</span></div>'''
def oc(name,trust,tcls,no,items,base,code,time,note=''):
    return f'''<div class="card" style="padding:12px 14px">
<div class="row g8"><img src="assets/placeholder-avatar.png" style="width:34px;height:34px;border-radius:50%"><div class="col sp"><div class="row g6"><b class="fd" style="font-size:15px">{name}</b><span class="trust {tcls}">{trust}</span></div><span class="xs muted bold">{no} · {time}</span></div>{I("more",20,'var(--b3)')}</div>
<div class="row g10" style="margin-top:10px">{receipt('Rp '+base+'.'+code)}<div class="col sp g4"><span class="xs muted bold">{items}</span><span class="xs muted bold">Harus diterima</span><b class="fd" style="font-size:20px;line-height:1">Rp {base}.<span class="code">{code}</span></b><span class="xs bold" style="color:var(--m-d)">✓ Nominal cocok dengan kode unik</span></div></div>
{note}
<div class="row g8" style="margin-top:10px"><div class="btn sm ghost" style="width:84px">Tolak</div><div class="btn sm mint sp">{I("check",17,None,3)}Tandai dibayar</div></div></div>'''
tabs=[('Perlu cek','5',1),('Dibayar','12',0),('Siap','8',0),('Selesai','',0)]
s2=f'''<div class="hdr" style="padding-top:2px"><h1 class="sp" style="font-size:22px">Pesanan</h1><span class="bk" style="width:40px;height:40px;border-radius:14px;background:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 0 var(--line)">{I("search",19)}</span></div>
<div class="pad"><div class="row" style="background:#F6EBDD;border-radius:16px;padding:4px;gap:2px">{''.join(f'<div class="sp row" style="justify-content:center;gap:4px;height:36px;border-radius:12px;font-weight:800;font-size:13px;{"background:#fff;color:var(--o-d);box-shadow:0 2px 0 var(--line)" if a else "color:var(--b2)"}">{t}'+(f'<span style="background:{"var(--o)" if a else "#E2D3C3"};color:{"#fff" if a else "var(--b2)"};border-radius:99px;font-size:10px;padding:1px 6px">{n}</span>' if n else '')+'</div>' for t,n,a in tabs)}</div></div>
<div class="pad col g10" style="margin-top:10px">
 <div class="row g8 xs bold" style="background:var(--o3);border-radius:12px;padding:8px 10px;color:var(--b)">{I("info",16,'var(--o)')}Cocokkan 3 digit terakhir dengan mutasi rekening BCA-mu.</div>
 {oc('Sari Dewi','⭐ Langganan Setia','t-vip','#PSN-1207','2 Ori · 2 Keju · 1 Kopi · Ambil','75','137','5 mnt lalu')}
 {oc('Budi Santoso','Baru','t-new','#PSN-1211','3 Ori · Diantar','58','482','12 mnt lalu','<div class="row g6 xs bold" style="margin-top:8px;color:#8A6A00;background:#FFF8DB;border-radius:10px;padding:6px 9px">'+I("info",14)+'Pembeli baru, belum ada riwayat. Cek bukti dengan teliti ya.</div>')}
 {oc('Rizky A.','Terpercaya','t-ok','#PSN-1213','1 Cokelat · 2 Kopi · Ambil','48','219','20 mnt lalu')}
</div>{NAV('Pesanan')}'''
page('s2-orders',s2,cust=False)

# ================= SELLER 3: PO EDITOR =================
def fld(l,v,ic='cal'):
    return f'<div class="col sp"><span class="lbl">{l}</span><div class="inp" style="height:40px;font-size:13px;font-weight:700">{I(ic,15,"var(--o)")}{v}</div></div>'
def pr(img,n,p,q,note=''):
    return f'<div class="row g10" style="padding:7px 0;border-bottom:1px dashed var(--line)">{img}<div class="col sp"><b style="font-size:14px">{n}</b><span class="xs muted bold">{p} · kuota {q}</span>{note}</div>{I("edit",17,"var(--b3)")}</div>'
s3=f'''<div class="hdr" style="padding-top:0"><div class="bk">{I("back",20)}</div><div class="col sp"><h1>Edit PO Batch #12</h1><span class="xs bold" style="color:#2EAD5B">● Lagi jalan · 32 pcs terpesan</span></div><div class="btn sm" style="height:36px">Simpan</div></div>
<div class="pad col g10" style="margin-top:2px">
 <div class="card" style="padding:12px 14px"><div class="sec">Periode PO</div>
  <div class="row g8">{fld('Buka','10 Nov, 08.00')}{fld('Tutup','14 Nov, 20.00')}</div>
  <div class="row g8" style="margin-top:8px">{fld('Ambil / kirim','Sab, 15 Nov','bag')}<div class="col sp"><span class="lbl">Total kuota</span><div class="stepper" style="height:40px;justify-content:space-between;background:#FFFCF8;border:1.5px solid var(--line)"><span>−</span><b>50 pcs</b><span>+</span></div></div></div></div>
 <div class="card" style="padding:12px 14px;border:2px solid var(--o2)"><div class="row"><div class="col sp"><b class="fd" style="font-size:15px">🎉 Kampanye diskon</b><span class="xs muted bold">Muncul sebagai chip di halaman toko</span></div><div class="toggle on"></div></div>
  <div class="row g8" style="margin-top:8px"><div class="col sp"><span class="lbl">Min. order</span><div class="inp" style="height:38px;font-weight:800">3 <span class="muted small">pcs</span></div></div><div class="col sp"><span class="lbl">Diskon</span><div class="inp" style="height:38px;font-weight:800">10 <span class="muted small">%</span></div></div></div></div>
 <div class="card" style="padding:10px 14px"><div class="row" style="margin-bottom:2px"><span class="sec sp" style="margin:0">Biaya tambahan</span><span class="small bold" style="color:var(--o-d)">+ Tambah</span></div>
  <div class="row g8" style="padding:6px 0">📦<div class="col sp"><b class="small">Packing</b><span class="xs muted bold">Rp 3.000 / pesanan</span></div><div class="toggle on" style="transform:scale(.85)"></div></div>
  <div class="row g8" style="padding:6px 0;border-top:1px dashed var(--line)">🛵<div class="col sp"><b class="small">Ongkir dalam cluster</b><span class="xs muted bold">Rp 10.000 · hanya jika diantar</span></div><div class="toggle on" style="transform:scale(.85)"></div></div></div>
 <div class="card" style="padding:8px 14px"><div class="row"><span class="sec sp" style="margin:4px 0 0">Produk di PO ini</span><span class="small bold" style="color:var(--o-d)">+ Produk</span></div>
  {pr(food('🥐',BREAD,44,24,12),'Salt Bread Original','Rp 15.000','24')}
  {pr(food('☕',COF,44,24,12),'Kopi Susu Gula Aren','Rp 15.000','20')}
  {pr(ph(44,12),'Salt Bread Cokelat','Rp 18.000','10','<span class="xs bold" style="color:var(--o-d)">📷 Belum ada foto · pakai placeholder</span>')}
 </div>
</div>{NAV('PO')}'''
page('s3-po-editor',s3,cust=False)

# ================= SELLER 4: RECAP =================
def tot(e,bg,n,q,u='pcs'):
    return f'<div class="card col" style="padding:9px 10px;gap:4px">{food(e,bg,34,19,10)}<b class="fd" style="font-size:20px;line-height:1">{q}<span class="xs muted" style="font-family:Nunito;font-weight:800"> {u}</span></b><span class="xs muted bold" style="line-height:1.15">{n}</span></div>'
def ck(done,n,t,tc,items,m):
    box=(f'<span style="width:26px;height:26px;border-radius:9px;background:var(--m);color:#fff;display:flex;align-items:center;justify-content:center;flex:none">{I("check",15,None,3.2)}</span>' if done else '<span style="width:26px;height:26px;border-radius:9px;border:2.5px solid #D8C9BB;background:#fff;flex:none"></span>')
    mc='t-ok' if m=='Ambil' else 't-vip'
    return f'<div class="row g10" style="padding:9px 0;border-bottom:1px dashed var(--line);{"opacity:.55" if done else ""}">{box}<div class="col sp"><div class="row g6"><b class="small" style="{"text-decoration:line-through" if done else ""}">{n}</b><span class="trust {tc}" style="font-size:10px">{t}</span></div><span class="xs muted bold">{items}</span></div><span class="trust {mc}" style="background:{"#E8F2FD" if m=="Antar" else ""};color:{"#2F8BE6" if m=="Antar" else ""}">{m}</span></div>'
s4=f'''<div class="hdr" style="padding-top:0"><div class="bk">{I("back",20)}</div><div class="col sp"><h1>Rekap produksi</h1><span class="xs muted bold">PO Batch #12 · Ambil Sab, 15 Nov</span></div></div>
<div class="pad col g10">
 <div class="row" style="background:var(--b);color:#fff;border-radius:18px;padding:10px 14px;gap:10px"><span class="food" style="font-size:24px">👩‍🍳</span><div class="col sp"><b class="fd" style="font-size:16px">Total masak: 44 roti + 18 kopi</b><span class="xs bold" style="opacity:.8">dari 21 pesanan dibayar · siap dipanggang Sabtu 05.00</span></div></div>
 <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">{tot('🥐',BREAD,'Original','24')}{tot('🧀',CHEESE,'Keju','14')}{tot('🍫',CHOC,'Cokelat','6')}{tot('☕',COF,'Kopi Aren','18','btl')}</div>
 <div class="card" style="padding:10px 14px 4px">
  <div class="row" style="margin-bottom:4px"><span class="sec sp" style="margin:0">Checklist ambil / antar</span><span class="trust t-ok" style="font-size:12px">8/21 beres</span></div>
  <div class="bar m" style="height:7px;margin:4px 0 4px"><i style="width:38%"></i></div>
  {ck(True,'Sari Dewi','⭐ Langganan Setia','t-vip','2 Ori · 2 Keju · 1 Kopi','Ambil')}
  {ck(False,'Budi Santoso','Baru','t-new','3 Ori','Antar')}
  {ck(False,'Rizky A.','Terpercaya','t-ok','1 Cokelat · 2 Kopi','Ambil')}
  {ck(False,'Maya Kurnia','Terpercaya','t-ok','4 Keju · 2 Kopi','Ambil')}
  {ck(False,'Pak Hendra','⭐ Langganan Setia','t-vip','6 Ori · 3 Kopi','Antar')}
 </div>
 <div class="row g8"><div class="btn wa sp" style="height:46px;font-size:15px">{I("wa",19)}Bagikan ke WA</div><div class="btn ghost" style="height:46px;width:128px;font-size:15px">{I("dl",18)}Export</div></div>
</div>{NAV('PO')}'''
page('s4-recap',s4,cust=False)

# ================= SELLER 5: KOIN + SHARE =================
def pk(v,sub,sel=False,tag=''):
    st='border:2.5px solid var(--o);background:var(--o3)' if sel else 'border:2px solid var(--line);background:#fff'
    return f'<div class="col" style="border-radius:16px;padding:8px 2px;align-items:center;{st};position:relative">'+(f'<span style="position:absolute;top:-9px;background:var(--m);color:#fff;font-size:9px;font-weight:900;border-radius:99px;padding:1px 6px">{tag}</span>' if tag else '')+f'<b class="fd" style="font-size:15px;color:{"var(--o-d)" if sel else "var(--b)"}">{v}</b><span class="muted" style="font-size:9.5px;font-weight:800;white-space:nowrap">{sub}</span></div>'
def tx(ic,bg,t,s,v,c):
    return f'<div class="row g10" style="padding:6px 0"><span style="width:30px;height:30px;border-radius:10px;background:{bg};display:flex;align-items:center;justify-content:center;font-size:14px">{ic}</span><div class="col sp"><b class="small">{t}</b><span class="xs muted bold">{s}</span></div><b class="fd" style="color:{c}">{v}</b></div>'
s5=f'''<div class="hdr" style="padding-top:0"><h1 class="sp" style="font-size:22px">Koin</h1><span class="small bold muted">Riwayat lengkap</span></div>
<div class="pad col g10">
 <div class="row g12" style="border-radius:20px;padding:12px 14px;color:#fff;background:linear-gradient(125deg,#FFA445,#F7861E 55%,#EA6A0C);box-shadow:0 4px 0 var(--o-d)"><span class="koin" style="width:38px;height:38px;font-size:18px">★</span><div class="col sp"><span class="xs bold" style="opacity:.9">Saldo · 1 koin = Rp 1</span><b class="fd" style="font-size:26px;line-height:1.05">12.450 koin</b></div><span class="xs bold" style="text-align:right;opacity:.95">≈ 124<br>pesanan</span></div>
 <div class="card" style="padding:12px 14px">
  <div class="sec">Top up koin</div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:7px">{pk('25rb','25.000 koin')}{pk('50rb','50.000 koin',True,'Favorit')}{pk('100rb','100.000 koin')}{pk('Custom','min. 10rb')}</div>
  <div style="margin-top:9px;background:#FFFCF8;border-radius:12px;padding:7px 10px;border:1.5px solid var(--line)">{ln('Top up','Rp 50.000')}{ln('Biaya admin','Rp 2.500')}<div class="div" style="margin:3px 0"></div><div class="row"><b class="sp small">Transfer ke BCA 8800 1234 56</b><b class="fd" style="color:var(--o-d)">Rp 52.500</b></div></div>
  <div class="row g8" style="margin-top:9px"><span class="xs muted bold sp" style="line-height:1.3">a.n. PT Pesenin Digital<br>Dicek admin maks. 1×24 jam</span><div class="btn sm">Top up</div></div>
 </div>
 <div class="card" style="padding:6px 14px">
  {tx('🧾','var(--o3)','Pesanan #PSN-1207 dibayar','Hari ini 18.45','−100','var(--b)')}
  {tx('🧾','var(--o3)','Pesanan #PSN-1206 dibayar','Hari ini 18.02','−100','var(--b)')}
  {tx('⬆️','var(--m2)','Top up disetujui','10 Nov · Rp 50.000','+50.000','var(--m-d)')}
 </div>
 <div class="row g12" style="border-radius:20px;padding:12px;background:var(--b);color:#fff">
  <div style="background:#fff;border-radius:14px;padding:7px;flex:none;position:relative"><img src="assets/qr.svg" style="width:82px;height:82px;display:block"><img src="assets/icon.png" style="position:absolute;left:50%;top:50%;width:24px;height:23px;transform:translate(-50%,-50%);background:#fff;border-radius:6px;padding:1px"></div>
  <div class="col sp g4"><b class="fd" style="font-size:18px;line-height:1.1">Hungry? <span style="color:#FFB04D">Ping me</span></b><span class="xs bold" style="opacity:.85">Scan buat pesan · pesenin.product.biz.id/dapur-senja</span>
   <div class="row g6" style="margin-top:4px"><div class="btn sm" style="height:32px;font-size:13px;padding:0 10px">{I("share",14)}Bagikan</div><div class="btn sm" style="height:32px;font-size:13px;padding:0 10px;background:#fff;color:var(--b);box-shadow:0 3px 0 #C9B3A4">{I("dl",14)}QR</div></div></div>
 </div>
</div>{NAV('Koin')}'''
page('s5-koin-share',s5,cust=False)
print('built')
