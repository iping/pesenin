from PIL import Image, ImageDraw, ImageFont, ImageFilter
F='/usr/share/fonts/truetype/sand-box/google/'
def font(path,size,w=None):
    f=ImageFont.truetype(F+path,size)
    if w:
        try: f.set_variation_by_axes([w,100] if 'Fredoka' in path else [w])
        except Exception as e: print(e)
    return f
FD=lambda s,w=600: font('Fredoka/Fredoka-VariableFont_wdth,wght.ttf',s,w)
NU=lambda s,w=700: font('Nunito/Nunito-VariableFont_wght.ttf',s,w)
BR=(74,42,26); OR=(247,134,30); CR=(255,246,234)
def phone(png):
    sc=Image.open(png).convert('RGB')  # 780x1688
    bez=26; W,H=sc.width+bez*2, sc.height+bez*2
    ph=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(ph)
    d.rounded_rectangle((0,0,W-1,H-1),radius=120,fill=(43,27,20))
    d.rounded_rectangle((6,6,W-7,H-7),radius=114,fill=(25,16,12))
    m=Image.new('L',sc.size,0); ImageDraw.Draw(m).rounded_rectangle((0,0,sc.width-1,sc.height-1),radius=96,fill=255)
    ph.paste(sc,(bez,bez),m)
    # dynamic island
    d.rounded_rectangle((W//2-110,bez+20,W//2+110,bez+82),radius=31,fill=(10,8,6))
    return ph
def sheet(items,title,sub,out):
    phs=[phone(f'screens/{n}.png') for n,_,_ in items]
    pw,ph_=phs[0].size; gap=90; mx=120; top=330; lab=230
    W=mx*2+pw*5+gap*4; H=top+ph_+lab+120
    im=Image.new('RGB',(W,H),CR); d=ImageDraw.Draw(im)
    # dots bg
    for x in range(0,W,60):
        for y in range(0,H,60): d.ellipse((x,y,x+5,y+5),fill=(247,232,212))
    ic=Image.open('src/assets/icon.png').convert('RGBA'); ic=ic.resize((170,int(170*ic.height/ic.width)))
    im.paste(ic,(mx,80),ic)
    d.text((mx+200,78),title,font=FD(96),fill=BR)
    d.text((mx+204,200),sub,font=NU(44,700),fill=(140,107,90))
    tg='Hungry? Ping me'; f=FD(64); tw=d.textlength(tg,font=f)
    d.rounded_rectangle((W-mx-tw-80,100,W-mx,200),radius=50,fill=OR)
    d.text((W-mx-tw-40,112),tg,font=f,fill=(255,255,255))
    for i,(p,(n,t,s)) in enumerate(zip(phs,items)):
        x=mx+i*(pw+gap)
        sh=Image.new('RGBA',(pw+120,ph_+120),(0,0,0,0)); ImageDraw.Draw(sh).rounded_rectangle((60,80,pw+60,ph_+60),radius=120,fill=(74,42,26,70))
        sh=sh.filter(ImageFilter.GaussianBlur(28)); im.paste(sh,(x-60,top-60),sh)
        im.paste(p,(x,top),p)
        y=top+ph_+60
        d.ellipse((x,y,x+76,y+76),fill=OR); num=str(i+1); f=FD(48); d.text((x+38,y+38),num,font=f,fill=(255,255,255),anchor='mm')
        d.text((x+100,y-2),t,font=FD(54),fill=BR)
        d.text((x+100,y+70),s,font=NU(34,700),fill=(140,107,90))
    im.save(out,optimize=True); print(out,im.size)
cust=[('c1-store','Halaman toko','Link toko, status Buka, PO & kampanye'),('c2-checkout','Keranjang & checkout','Tamu/Google, pickup, biaya & diskon'),('c3-payment','Pembayaran','Transfer BCA + kode unik 137'),('c4-status','Status pesanan','Timeline, WA penjual, trust badge'),('c5-review','Ulasan Mangkok','1–3 Mangkok, khusus pembeli valid')]
sell=[('s1-dashboard','Beranda','Toggle buka, koin, statistik, streak'),('s2-orders','Pesanan','Cek bukti, kode unik, trust grade'),('s3-po-editor','Atur PO','Periode, kuota, kampanye, biaya'),('s4-recap','Rekap produksi','Total per produk + checklist ambil'),('s5-koin-share','Koin & QR toko','Top up, riwayat, Hungry? Ping me')]
sheet(cust,'Pesenin · Customer','Mobile browser (PWA 390×844) · pesan lewat link toko, tanpa wajib daftar','customer-screens.png')
sheet(sell,'Pesenin · Seller','Mobile browser / PWA terpasang (390×844) · kelola toko, PO, pesanan & koin','seller-screens.png')
